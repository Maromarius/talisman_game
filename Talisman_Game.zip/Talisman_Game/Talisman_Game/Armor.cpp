#include "Armor.h"
#include <string>
#include <iostream>

using namespace std;



Armor::Armor(string name,string description) : Object(name,description)
{
	
}