Rami Kuret
9770925

I did the Object(Weapon and Armor) section.

You just need to run the main class located in the main.cpp file.
   
                                                 
           

                           