#include "Weapon.h"
#include <string>
#include <iostream>

using namespace std;



Weapon::Weapon(string name,string description) : Object(name, description)
{
	
}